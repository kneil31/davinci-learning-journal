# My First Edit – Housewarming Ceremony

## 🎬 What I Did
- Imported clips from two families
- Trimmed redundant parts
- Added title “Welcome Home”

## 💡 What I Learned
- Edit tab gives full flexibility
- Music and titles add emotion

## 🛠 What I’ll Improve
- Try crossfade transitions
- Organize clips better in bins