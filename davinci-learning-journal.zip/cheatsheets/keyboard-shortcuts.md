# 🧠 DaVinci Resolve Keyboard Shortcuts Cheat Sheet

| Action         | Shortcut         |
|----------------|------------------|
| Blade Tool     | `B`              |
| Selection Tool | `A`              |
| Undo           | `Ctrl + Z`       |
| Redo           | `Ctrl + Shift + Z` |
| Play/Pause     | `Spacebar`       |
| Zoom Timeline  | `Ctrl + Scroll`  |
