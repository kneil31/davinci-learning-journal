# 🎥 Helpful Tutorials & Links

## Beginner-Friendly
- [DaVinci Resolve in 12 Minutes (2025)](https://www.youtube.com/watch?v=SrJOE2pEp7A) – Full basic workflow.

## Official Resources
- [Blackmagic Training](https://www.blackmagicdesign.com/products/davinciresolve/training) – In-depth PDF + projects

## Tip Channels
- Casey Faris
- MrAlexTech
- Josh Olufemii