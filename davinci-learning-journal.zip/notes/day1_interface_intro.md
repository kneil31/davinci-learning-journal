# Day 1 – Interface Introduction

## Tabs Explored
- Media: For importing and organizing footage
- Cut: Quick, streamlined edits
- Edit: Full timeline editing with effects and transitions

## Key Learnings
- How to navigate between tabs
- Blade tool (`B`) and Selection tool (`A`)
- Created first project file

## To Revisit
- Difference between Cut and Edit workflows
- Timeline zoom shortcuts