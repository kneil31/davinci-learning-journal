# Day 2 – Importing & Timeline Basics

## Workflow
- Imported housewarming clips into Media Pool
- Dragged clips into timeline (Edit tab)
- Used Razor tool for trimming

## Lessons
- Enable snapping for aligned cuts
- Added basic markers
- Used `Ctrl+Z` (Undo) heavily!

## Next Steps
- Learn to add transitions and basic titles